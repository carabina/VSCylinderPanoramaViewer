//
//  ViewController.swift
//  Test
//
//  Created by PJ Vea on 10/14/15.
//  Copyright © 2015 Vea Software. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidAppear(animated: Bool)
    {
        super.viewDidAppear(animated)
        let vc = VSCylinderPanoramaViewer()
        vc.imageName = "photo"
        self.presentViewController(vc, animated: true, completion: nil)
    }
}

